import{s}from"../chunks/scheduler.Dw1Xknx6.js";import{S as t,i as e}from"../chunks/index.BjN0RBxD.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
