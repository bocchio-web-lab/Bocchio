import{a as t}from"../chunks/entry.DRO86FrP.js";export{t as start};
